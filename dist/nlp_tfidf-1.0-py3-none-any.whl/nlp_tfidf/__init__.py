from .qa import Qa

__version__ = "1.0"
